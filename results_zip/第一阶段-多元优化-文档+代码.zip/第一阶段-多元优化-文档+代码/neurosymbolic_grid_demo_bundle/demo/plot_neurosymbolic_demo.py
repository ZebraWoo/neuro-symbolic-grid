#!/usr/bin/env python3
"""Plot training results for the Neuro-Symbolic Grid Control Demo."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--history-file", type=str,
                        default="demo/ns_results/ns_history.json")
    parser.add_argument("--output-dir", type=str,
                        default="demo/ns_results")
    args = parser.parse_args()

    with open(args.history_file, "r") as f:
        h = json.load(f)

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ep = np.arange(1, len(h["total_penalty"]) + 1)

    # ---- 1) Penalty Decomposition ----
    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(ep, h["total_penalty"], "k-", lw=2.5, label="Total Penalty")
    ax.plot(ep, h["kcl_penalty"], lw=1.8, label="KCL Penalty")
    ax.plot(ep, h["v_penalty"], lw=1.8, label="Voltage Penalty")
    ax.plot(ep, h["flow_penalty"], lw=1.8, label="Flow Penalty")
    ax.plot(ep, h["comp_penalty"], lw=1.8, label="Complement Penalty")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Penalty")
    ax.set_title("Neuro-Symbolic Penalty Decomposition (Real PSML Data)")
    ax.grid(alpha=0.3); ax.legend()
    plt.tight_layout(); plt.savefig(out / "ns_penalty_curve.png", dpi=150)
    plt.close()
    print(f"Saved: {out / 'ns_penalty_curve.png'}")

    # ---- 2) Logic Truth Values ----
    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(ep, h["kcl_truth"], lw=2, label="KCL Truth")
    ax.plot(ep, h["voltage_truth"], lw=2, label="Voltage Truth")
    ax.plot(ep, h["flow_truth"], lw=2, label="Flow Truth")
    ax.plot(ep, h["complement_truth"], lw=2, label="Complement Truth")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Soft Truth"); ax.set_ylim(0, 1)
    ax.set_title("Logic Neuron Truth Values (Real PSML Data)")
    ax.grid(alpha=0.3); ax.legend()
    plt.tight_layout(); plt.savefig(out / "ns_truth_curve.png", dpi=150)
    plt.close()
    print(f"Saved: {out / 'ns_truth_curve.png'}")

    # ---- 3) Summary Report ----
    best = int(np.argmin(np.array(h["total_penalty"])) + 1)
    drop = ((h["total_penalty"][0] - h["total_penalty"][-1])
            / h["total_penalty"][0] * 100) if h["total_penalty"][0] != 0 else 0

    lines = [
        "Neuro-Symbolic Grid Control Demo — Summary",
        "=" * 58, "",
        f"Epochs: {len(ep)}", "",
        "Penalty Metrics",
        f"  Initial total penalty: {h['total_penalty'][0]:.4f}",
        f"  Final total penalty:   {h['total_penalty'][-1]:.4f}",
        f"  Total reduction:       {drop:.1f}%",
        f"  Best total penalty:    {np.min(h['total_penalty']):.4f} (Epoch {best})", "",
        "Final Constraint Penalties",
        f"  KCL:              {h['kcl_penalty'][-1]:.6f}",
        f"  Voltage:          {h['v_penalty'][-1]:.6f}",
        f"  Flow (Tie-line):  {h['flow_penalty'][-1]:.6f}",
        f"  Complement:       {h['comp_penalty'][-1]:.6f}", "",
        "Final Logic Truth Values (higher is better)",
        f"  KCL Truth:        {h['kcl_truth'][-1]:.4f}",
        f"  Voltage Truth:    {h['voltage_truth'][-1]:.4f}",
        f"  Flow Truth:       {h['flow_truth'][-1]:.4f}",
        f"  Complement Truth: {h['complement_truth'][-1]:.4f}", "",
        "Data Info",
        f"  Mean load (z-score):  {np.mean(h['mean_load']):.4f}",
        f"  Mean renewable:       {np.mean(h['mean_ren']):.4f}", "",
        "Key Takeaway",
        "  Real PSML data → differentiable symbolic penalty gradients",
        "  → neural controller learns to satisfy grid safety constraints.",
    ]

    fig = plt.figure(figsize=(11, 7)); ax = fig.add_subplot(111)
    ax.axis("off")
    ax.text(0.05, 0.95, "\n".join(lines), transform=ax.transAxes,
            va="top", ha="left", fontsize=11.5, family="monospace",
            bbox=dict(boxstyle="round", facecolor="whitesmoke", alpha=0.9))
    plt.tight_layout(); plt.savefig(out / "summary_report.png", dpi=150)
    plt.close()
    print(f"Saved: {out / 'summary_report.png'}")
    print("Done.")


if __name__ == "__main__":
    main()
